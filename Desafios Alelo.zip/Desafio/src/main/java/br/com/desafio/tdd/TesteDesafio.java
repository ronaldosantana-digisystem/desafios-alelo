package br.com.desafio.tdd;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;

import br.com.desafio.function.FuncoesSelenium;


public class TesteDesafio {
	
	
	@Test
	public void test_Desafio() {
		FuncoesSelenium fs = new FuncoesSelenium();
		fs.inicializaNavegadorChrome(System.getProperty("user.dir") + "\\target\\chromedriver.exe", System.getProperty("user.dir") + "\\target\\index.html");
		
		fs.escreverTexto(By.id("txtNomeDiretor"), "Peter Jackson");
		fs.escreverTexto(By.id("txtNascDiretor"), "31 de outubro de 1961");
		fs.escreverTexto(By.id("txtNomeFilme"), "Senhor dos an�is");
		fs.escreverTexto(By.id("txtDataLancamento"), "1 de janeiro de 2002");
		
		List<String> nomeDiretor = new ArrayList<String>();
		List<String> nascDiretor = new ArrayList<String>();
		List<String> nomeFilme = new ArrayList<String>();
		List<String> dataLancamento = new ArrayList<String>();
		
		nomeDiretor.add(fs.obterValorDoCampo(By.id("txtNomeDiretor")));
		nascDiretor.add(fs.obterValorDoCampo(By.id("txtNascDiretor")));
		nomeFilme.add(fs.obterValorDoCampo(By.id("txtNomeFilme")));
		dataLancamento.add(fs.obterValorDoCampo(By.id("txtDataLancamento")));
		
		fs.clicar(By.id("botao"));
		fs.aguardarCarregamentoDePagina();
		
		
		fs.escreverTexto(By.name("q"), nomeDiretor.get(0));
		fs.escreverTexto(By.name("q"), " " + nomeFilme.get(0));
		fs.enter();
		fs.aguardarCarregamentoDePagina();
		
		String buscaAproximada = fs.obterTexto(By.id("result-stats"));
		assertEquals("Aproximadamente "+ buscaAproximada.substring(16, 23) + " resultados", buscaAproximada.substring(0, 34));
		
		
	}
	
}
