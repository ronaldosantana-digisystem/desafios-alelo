package br.com.desafio.function;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FuncoesSelenium {
	private WebDriver driver;

	public void inicializaNavegadorChrome(String setPropertyPathDriver, String pathNavigation) {
		if (driver == null) {
			System.setProperty("webdriver.chrome.driver", setPropertyPathDriver);
			driver = new ChromeDriver();
			driver.get(pathNavigation);
		}
	}

	public String escreverTexto(By by, String texto) {

		if (driver.findElement(by).isDisplayed() && driver.findElement(by).isEnabled()) {
			driver.findElement(by).sendKeys(texto);
			return driver.findElement(by).getAttribute("value");
		} else {
			return "Ocorreu um erro ao identificar o elemento";
		}
	}

	public String obterValorDoCampo(By by) {
		if (driver.findElement(by).getAttribute("value") == "") {
			return "N�o existe nenhum valor no campo.";
		} else {
			return driver.findElement(by).getAttribute("value");
		}

	}

	public void clicar(By by) {
		WebElement botao = driver.findElement(by);
		if (botao != null && botao.isDisplayed() && botao.isEnabled()) {
			botao.click();
		} else {
			System.out.println("elemento n�o encontrado");
		}
	}

	public void enter() {
		// Open tab 2 using CTRL + t keys.
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
	}

	public String obterTexto(By by) {
		WebElement elemento = driver.findElement(by);
		elemento.getText();
		if(elemento != null && elemento.isDisplayed() && elemento.isEnabled()) {
			return elemento.getText();
		}else {
			return "elemento n�o encontrato na pagina."; 
		}
	}
	
	public void aguardarCarregamentoDePagina() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}
