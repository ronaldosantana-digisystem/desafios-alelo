package restAssurred;

import static io.restassured.RestAssured.get;
import static org.hamcrest.core.IsEqual.equalTo;

import org.junit.Test;

public class RestAssuredDesafio {

	String url = "https://jsonplaceholder.typicode.com/todos/1";

	@Test
	public void getTitle() {
		get(url).then().body("title", equalTo("delectus aut autem"));
	}
}
